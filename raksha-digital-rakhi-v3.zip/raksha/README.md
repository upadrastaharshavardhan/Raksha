# 🛡️ Raksha – Your Digital Rakhi (V3)

**Stronger multi-WhatsApp SOS for every sister.**

## What’s New in V3

### Much better SOS
- Big **“I’m in Trouble”** button
- Opens **WhatsApp for every trusted contact** one by one
- Live location + emergency message is already written in the chat
- You only need to tap **Send** on each chat
- Same message is also copied to clipboard (can paste in SMS, Instagram etc.)
- Clear progress screen shows which contacts are being opened

### Why not 100% automatic?
Browsers block fully automatic WhatsApp / SMS / phone calls for security.
This is the strongest possible version without a paid backend or native app.

### Other features still present
- Custom Voice Trigger (“Bhairava help me” etc.)
- Fake Call, Siren, Flashlight
- Safety Check-In timer
- One-tap Indian helplines (112, 1091, 181…)
- Private period tracker
- Works offline after first open

## How to gift
1. Upload the `raksha` folder to https://app.netlify.com/drop
2. Share the permanent link with your sister
3. Tell her: Open in Chrome (Android) or Safari (iPhone) → Add to Home Screen

Made with ❤️ for every sister.
