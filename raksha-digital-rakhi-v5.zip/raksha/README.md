# 🛡️ Raksha V5 – Instant Primary SOS (Free Emergency Approach)

## Best free emergency handling

In a real emergency she may only be able to do 1–2 actions.

### How V5 works
1. In **Circle** tab, the **first person** is the **Primary** contact (you can “Make Primary”).
2. Hold the red SOS button (or use voice phrase).
3. App **instantly opens that Primary person’s WhatsApp** with the full emergency message + live location already written.
4. She only needs to tap **Send** once.
5. Message is also copied to clipboard.
6. After a second, a panel appears so she can still alert other Circle people if she has time.

### Setup (do this once)
1. Open Circle tab
2. Add the most important person first (brother / father) with correct +91 number
3. Add other people after that
4. You can tap “Make Primary” anytime to change who opens first

### Why this is the best free method
Browsers cannot send WhatsApp fully automatically.  
Opening the single most important contact instantly is the fastest reliable free solution for real emergencies.

### Still available
- Voice trigger (“Bhairava help me” etc.)
- Fake Call, Siren, Flashlight
- Safety Check-In
- Helplines (112, 1091…)
- Private period tracker

Made with ❤️ for every sister.
