# 🛡️ Raksha – Your Digital Rakhi (V2)

**A free, private, ready-to-gift safety companion for every sister.**  
Now with **Custom Voice Trigger** (like “Hey Siri”).

Gifted with love on Raksha Bandhan.

---

## What’s New in V2

### 🎙️ Custom Voice Trigger
- Set any secret phrase you want (example: **“Bhairava help me”**)
- Turn Voice Guard ON
- When the phone hears the phrase → SOS + location is sent automatically to her Trusted Circle
- Works best on **Chrome / Edge on Android**
- Completely private – voice is processed only on the device

Suggested phrases:
- Bhairava help me
- Raksha help me
- Brother help me
- Help me now
- Emergency help

---

## How to Gift This

### Best way (recommended)
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag the entire `raksha` folder
3. You get a permanent link
4. Send the link to your sister

### Quick way
- Send her the folder / zip
- She opens `index.html` in Chrome → Add to Home Screen

---

## Full Features

- **One-tap SOS** (hold 2 seconds)
- **Custom Voice Trigger** (new in V2)
- **Trusted Circle** (up to 7 people)
- **Fake Call**
- **Safety Check-In Timer**
- **Siren + Flashlight**
- **India + Global Helplines**
- **Private Period Tracker**
- **Safety Tips**
- Works offline after first open
- Installs like a real app

---

## Privacy Promise
Everything stays only on the device.  
No accounts. No servers. No tracking.  
Voice is never recorded or uploaded.

---

Made with ❤️ so every sister can feel a little safer, every day.
