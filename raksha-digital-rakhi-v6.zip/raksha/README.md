# 🛡️ Raksha V6 – SOS Alerter Style Flow (Free Web Version)

Closest free web version to SOS Alerter.

## Triggers (like SOS Alerter)
1. **Shake the phone** (enable on Home screen)
2. **Voice phrase** (e.g. “Bhairava help me”)
3. **Hold the red SOS button**

## What happens
- Instantly opens your **Primary** contact’s WhatsApp
- Message + live location already written
- You only tap **Send**
- Message also copied to clipboard
- Panel appears for other Circle contacts if you have time

## Setup once
1. Delete old Raksha icon → open new link → Add to Home Screen
2. Go to **Circle** → add most important person first (Primary)
3. On Home → tap **Enable Shake to SOS** (allow motion permission)
4. Set your voice phrase in Voice tab

## Limitation (honest)
Web apps cannot send SMS fully automatically when the phone is locked.
For true background automatic SMS, install the open-source **SOS Alerter** from F-Droid on Android.

This web version is the strongest free, zero-install gift for every sister.

Made with ❤️
