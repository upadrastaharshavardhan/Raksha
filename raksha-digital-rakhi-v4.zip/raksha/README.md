# 🛡️ Raksha – Your Digital Rakhi (V4)

Better handling for your key contacts.

## What was fixed in V4

Previously on iPhone the system Share sheet appeared and did not go to the people you added in Circle.

### V4 changes:
- SOS now shows a clear panel with **only your Circle contacts**
- Each person has their own **WhatsApp** and **SMS** button
- Tapping WhatsApp opens that exact person’s chat with the emergency message + live location already written
- You only need to tap **Send** inside WhatsApp
- “Open WhatsApp for All” goes one-by-one so you stay in control
- Message is always copied to clipboard as backup

## How to use (important)

1. Open **Circle** tab
2. Add your key people with correct WhatsApp number (include +91)
3. Hold the red SOS button or tap the green “Send WhatsApp Alert to All”
4. In the panel that opens, tap **WhatsApp** next to each person
5. When WhatsApp opens → just tap the green **Send** button

## Gift instructions
Upload the `raksha` folder to https://app.netlify.com/drop and share the link.

Made with ❤️ for every sister.
